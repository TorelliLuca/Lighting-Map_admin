import axios from 'axios'

export const api = axios.create({
  baseURL: import.meta.env.VITE_SERVER_URL || 'http://localhost:3000'
})

// Town Hall Services
export const townHallService = {
  getAll: () => api.get('/townHalls'),
  getByName: (name) => api.get(`/townHalls/${name}`),
  create: (data) => api.post('/townHalls', data),
  update: (data) => api.post('/townHalls/update', data),
  delete: (name) => api.delete('/townHalls', { data: { name } }),
  downloadExcel: (data) => api.post('/api/downloadExcelTownHall', data, { responseType: 'blob' })
}

// User Services
export const userService = {
  getAll: () => api.get('/users'),
  getByEmail: (email) => api.get(`/users/getForEmail/${email}`),
  addTownHall: (data) => api.post('/users/addTownHalls', data),
  removeTownHall: (data) => api.delete('/users/removeTownHalls', { data }),
  validateUser: (data) => api.post('/users/validateUser', data),
  removeUser: (data) => api.post('/users/removeUser', data),
  updateUser: (data) => api.post('/users/update/modifyUser', data),
  sendApprovalEmail: (data) => api.post('/send-email-to-user/isApproved', data)
}
