import { Suspense, lazy } from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { useUser } from './context/UserContext'
import MainLayout from './layouts/MainLayout'
import LoadingScreen from './components/common/LoadingScreen'

// Lazy load pages for better performance
const Dashboard = lazy(() => import('./pages/Dashboard'))
const AddUserPage = lazy(() => import('./pages/AddUserPage'))
const DownloadExcelDB = lazy(() => import('./pages/DownloadExcelDB'))
const UploadInCSVFormat = lazy(() => import('./pages/UploadInCSVFormat'))
const ValidateUser = lazy(() => import('./pages/ValidateUser'))
const ModifyUsers = lazy(() => import('./pages/ModifyUsers'))
const RemoveTownHallFromUser = lazy(() => import('./pages/RemoveTownHallFromUser'))
const RemoveTownHall = lazy(() => import('./pages/RemoveTownHall'))
const Login = lazy(() => import('./pages/Login'))
const NotFound = lazy(() => import('./pages/NotFound'))

function App() {
  const { userData, loading } = useUser()
  
  if (loading) {
    return <LoadingScreen />
  }

  return (
    <Suspense fallback={<LoadingScreen />}>
      <Routes>
        <Route path="/login" element={!userData ? <Login /> : <Navigate to="/" />} />
        
        <Route element={<MainLayout />}>
          <Route path="/" element={userData ? <Dashboard /> : <Navigate to="/login" />} />
          <Route path="/aggiungi-comune-utente" element={userData ? <AddUserPage /> : <Navigate to="/login" />} />
          <Route path="/scarica-report-in-excel" element={userData ? <DownloadExcelDB /> : <Navigate to="/login" />} />
          <Route path="/carica-comune-in-CSV-format" element={userData ? <UploadInCSVFormat /> : <Navigate to="/login" />} />
          <Route path="/valida-utente" element={userData ? <ValidateUser /> : <Navigate to="/login" />} />
          <Route path="/valida-utente/modifica-utente/:email" element={userData ? <ModifyUsers /> : <Navigate to="/login" />} />
          <Route path="/rimuovi-comune-da-utente" element={userData ? <RemoveTownHallFromUser /> : <Navigate to="/login" />} />
          <Route path="/rimuovi-comune" element={userData ? <RemoveTownHall /> : <Navigate to="/login" />} />
        </Route>
        
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Suspense>
  )
}

export default App
