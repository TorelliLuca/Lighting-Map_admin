import { NavLink } from 'react-router-dom'
import { X, Home, Users, Database, Upload, Download, UserCheck, UserMinus, Building } from 'lucide-react'
import { useUser } from '../../context/UserContext'

const Sidebar = ({ open, setOpen }) => {
  const { userData, logout } = useUser()
  
  const isAdmin = userData?.user_type === 'ADMINISTRATOR' || userData?.user_type === 'SUPER_ADMIN'
  
  const navigation = [
    { name: 'Dashboard', href: '/', icon: Home },
    { name: 'Aggiungi comune all\'utente', href: '/aggiungi-comune-utente', icon: Building },
    { name: 'Scarica DB comune', href: '/scarica-report-in-excel', icon: Download },
    { name: 'Carica comune in CSV', href: '/carica-comune-in-CSV-format', icon: Upload },
    { name: 'Gestisci utenti', href: '/valida-utente', icon: UserCheck, admin: true },
    { name: 'Rimuovi comune da utente', href: '/rimuovi-comune-da-utente', icon: UserMinus },
    { name: 'Elimina comune', href: '/rimuovi-comune', icon: Database, admin: true }
  ]
  
  // Filter navigation items based on user role
  const filteredNavigation = navigation.filter(item => !item.admin || isAdmin)

  return (
    <>
      {/* Mobile sidebar backdrop */}
      {open && (
        <div 
          className="fixed inset-0 z-20 bg-black/50 backdrop-blur-sm md:hidden"
          onClick={() => setOpen(false)}
        />
      )}
      
      {/* Sidebar */}
      <div className={`fixed inset-y-0 left-0 z-30 w-64 h-screen bg-slate-900/90 backdrop-blur-md border-r border-blue-900/30 transform transition-transform duration-300 ease-in-out md:translate-x-0 ${open ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex items-center justify-between h-16 px-4 border-b border-blue-900/30">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
              <span className="text-white font-bold">LM</span>
            </div>
            <span className="text-xl font-semibold text-white">Lighting-Map</span>
          </div>
          <button
            onClick={() => setOpen(false)}
            className="md:hidden inline-flex items-center justify-center p-2 rounded-md text-blue-400 hover:text-white hover:bg-blue-800/30 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-blue-500"
          >
            <span className="sr-only">Close sidebar</span>
            <X className="block h-6 w-6" aria-hidden="true" />
          </button>
        </div>
        
        <div className="flex flex-col flex-1 overflow-y-auto pt-5 pb-4">
          <nav className="mt-5 flex-1 px-2 space-y-1">
            {filteredNavigation.map((item) => (
              <NavLink
                key={item.name}
                to={item.href}
                className={({ isActive }) => 
                  `group flex items-center px-2 py-2 text-sm font-medium rounded-md ${
                    isActive 
                      ? 'bg-blue-800/30 text-white border-l-4 border-blue-500' 
                      : 'text-blue-100 hover:bg-blue-800/20'
                  }`
                }
              >
                <item.icon className="mr-3 h-5 w-5 text-blue-400" aria-hidden="true" />
                {item.name}
              </NavLink>
            ))}
          </nav>
        </div>
        
        <div className="flex-shrink-0 flex border-t border-blue-900/30 p-4">
          <div className="flex-shrink-0 w-full group block">
            <div className="flex items-center">
              <div className="h-9 w-9 rounded-full bg-blue-600 flex items-center justify-center text-white">
                {userData?.name?.charAt(0)}{userData?.surname?.charAt(0)}
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-white">{userData?.name} {userData?.surname}</p>
                <p className="text-xs font-medium text-blue-300 group-hover:text-blue-200">
                  {userData?.user_type === 'SUPER_ADMIN' ? 'Super Admin' : 
                   userData?.user_type === 'ADMINISTRATOR' ? 'Amministratore' : 
                   userData?.user_type === 'MAINTAINER' ? 'Manutentore' : 'Utente'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default Sidebar
