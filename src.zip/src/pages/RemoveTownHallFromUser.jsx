import { useState, useEffect } from 'react'
import { userService, townHallService } from '../services/api'
import PageHeader from '../components/common/PageHeader'
import Card, { CardBody, CardHeader } from '../components/common/Card'
import Select from '../components/common/Select'
import Button from '../components/common/Button'
import Alert from '../components/common/Alert'
import InfoCard from '../components/common/InfoCard'
import { Building, UserMinus } from 'lucide-react'
import toast from 'react-hot-toast'

const RemoveTownHallFromUser = () => {
  const [users, setUsers] = useState([])
  const [townHalls, setTownHalls] = useState([])
  const [selectedUser, setSelectedUser] = useState('')
  const [selectedTownHall, setSelectedTownHall] = useState('')
  const [loading, setLoading] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [alert, setAlert] = useState(null)
  const [isDataLoaded, setIsDataLoaded] = useState(false)

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true)
        const [usersResponse, townHallsResponse] = await Promise.all([
          userService.getAll(),
          townHallService.getAll()
        ])
        
        const approvedUsers = usersResponse.data.filter(user => user.is_approved)
        setUsers(approvedUsers)
        setTownHalls(townHallsResponse.data)
        
        // Find first user with assigned town halls
        const userWithTownHalls = approvedUsers.find(user => 
          user.town_halls_list.length > 0 &&
          user.town_halls_list.some(thId => 
            townHallsResponse.data.some(th => th._id === thId)
          )
        )
        
        if (userWithTownHalls && !isDataLoaded) {
          setSelectedUser(JSON.stringify({
            email: userWithTownHalls.email,
            town_halls_list: userWithTownHalls.town_halls_list
          }))
          
          // Find first assigned town hall
          const firstTownHall = townHallsResponse.data.find(th => 
            userWithTownHalls.town_halls_list.includes(th._id)
          )
          
          if (firstTownHall) {
            setSelectedTownHall(firstTownHall.name)
          }
          
          setIsDataLoaded(true)
        }
      } catch (error) {
        console.error('Error fetching data:', error)
        toast.error('Errore durante il caricamento dei dati')
      } finally {
        setLoading(false)
      }
    }
    
    fetchData()
  }, [])

  useEffect(() => {
    if (selectedUser && townHalls.length > 0) {
      const user = JSON.parse(selectedUser)
      const assignedTownHall = townHalls.find(th => 
        user.town_halls_list.includes(th._id)
      )
      
      if (assignedTownHall) {
        setSelectedTownHall(assignedTownHall.name)
      }
    }
  }, [selectedUser, townHalls])

  const handleUserChange = (e) => {
    const selectedUserIndex = e.target.value
    setSelectedUser(JSON.stringify({
      email: users[selectedUserIndex].email,
      town_halls_list: users[selectedUserIndex].town_halls_list
    }))
  }

  const handleTownHallChange = (e) => {
    setSelectedTownHall(e.target.value)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSubmitting(true)
    setAlert(null)
    
    try {
      const formData = {
        email: JSON.parse(selectedUser).email,
        townHall: selectedTownHall
      }
      
      const response = await userService.removeTownHall(formData)
      
      // Update local state
      const updatedUser = JSON.parse(selectedUser)
      const townHallToRemove = townHalls.find(th => th.name === selectedTownHall)
      
      if (townHallToRemove) {
        updatedUser.town_halls_list = updatedUser.town_halls_list.filter(
          thId => thId !== townHallToRemove._id
        )
        
        setSelectedUser(JSON.stringify(updatedUser))
        
        // Find next available town hall
        const nextTownHall = townHalls.find(th => 
          updatedUser.town_halls_list.includes(th._id)
        )
        
        if (nextTownHall) {
          setSelectedTownHall(nextTownHall.name)
        }
      }
      
      setAlert({
        type: 'success',
        message: response.data || 'Comune rimosso con successo'
      })
      
      toast.success('Comune rimosso con successo')
    } catch (error) {
      console.error('Error submitting form:', error)
      setAlert({
        type: 'error',
        message: error.response?.data || 'Errore durante la rimozione del comune'
      })
      
      toast.error('Errore durante la rimozione del comune')
    } finally {
      setSubmitting(false)
      setTimeout(() => setAlert(null), 5000)
    }
  }

  const getUserOptions = () => {
    return users
      .filter(user => {
        // Only show users with assigned town halls
        const hasTownHalls = user.town_halls_list.some(thId => 
          townHalls.some(th => th._id === thId)
        )
        return user.is_approved && hasTownHalls
      })
      .map((user, index) => ({
        value: index.toString(),
        label: `${user.name} ${user.surname}`
      }))
  }

  const getTownHallOptions = () => {
    if (!selectedUser) return []
    
    const user = JSON.parse(selectedUser)
    return townHalls
      .filter(th => user.town_halls_list.includes(th._id))
      .map(th => ({
        value: th.name,
        label: th.name
      }))
  }

  const getAssignedTownHalls = () => {
    if (!selectedUser) return []
    
    const user = JSON.parse(selectedUser)
    return user.town_halls_list
      .map(thId => townHalls.find(th => th._id === thId))
      .filter(Boolean)
  }

  return (
    <div>
      <PageHeader 
        title="Rimuovi comune da utente" 
        description="Revoca l'accesso di un utente a un comune specifico"
      />
      
      {alert && (
        <Alert 
          type={alert.type} 
          message={alert.message} 
          className="mb-6"
        />
      )}
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <h2 className="text-xl font-semibold text-white flex items-center">
                <UserMinus className="mr-2 h-5 w-5 text-blue-400" />
                Seleziona utente e comune
              </h2>
            </CardHeader>
            <CardBody>
              <form onSubmit={handleSubmit}>
                <Select
                  label="Seleziona l'utente da cui rimuovere il comune"
                  value={users.findIndex(user => user.email === (selectedUser ? JSON.parse(selectedUser).email : ''))}
                  onChange={handleUserChange}
                  options={getUserOptions()}
                  disabled={loading || getUserOptions().length === 0}
                />
                
                <Select
                  label="Seleziona il comune da rimuovere"
                  value={selectedTownHall}
                  onChange={handleTownHallChange}
                  options={getTownHallOptions()}
                  disabled={loading || !selectedUser || getTownHallOptions().length === 0}
                />
                
                <Button
                  type="submit"
                  variant="danger"
                  isLoading={submitting}
                  disabled={loading || !selectedUser || !selectedTownHall || getTownHallOptions().length === 0}
                  className="mt-4 w-full"
                >
                  {submitting ? 'Rimozione in corso...' : 'Rimuovi comune'}
                </Button>
              </form>
            </CardBody>
          </Card>
        </div>
        
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <h2 className="text-xl font-semibold text-white">Comuni assegnati</h2>
            </CardHeader>
            <CardBody>
              {getAssignedTownHalls().length === 0 ? (
                <p className="text-blue-300">Nessun comune assegnato a questo utente</p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {getAssignedTownHalls().map(th => (
                    <InfoCard
                      key={th._id}
                      title={th.name}
                      descriptionName="Punti luce"
                      descriptionValue={th.light_points}
                      icon={Building}
                    />
                  ))}
                </div>
              )}
            </CardBody>
          </Card>
        </div>
      </div>
    </div>
  )
}

export default RemoveTownHallFromUser
