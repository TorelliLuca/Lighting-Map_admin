import { useState, useEffect } from 'react'
import { userService, townHallService } from '../services/api'
import PageHeader from '../components/common/PageHeader'
import Card, { CardBody, CardHeader } from '../components/common/Card'
import Select from '../components/common/Select'
import Button from '../components/common/Button'
import Alert from '../components/common/Alert'
import InfoCard from '../components/common/InfoCard'
import { Building } from 'lucide-react'
import toast from 'react-hot-toast'

const AddUserPage = () => {
  const [users, setUsers] = useState([])
  const [townHalls, setTownHalls] = useState([])
  const [selectedUser, setSelectedUser] = useState('')
  const [selectedTownHall, setSelectedTownHall] = useState('')
  const [loading, setLoading] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [alert, setAlert] = useState(null)
  const [isDataLoaded, setIsDataLoaded] = useState(false)

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true)
        const [usersResponse, townHallsResponse] = await Promise.all([
          userService.getAll(),
          townHallService.getAll()
        ])
        
        const approvedUsers = usersResponse.data.filter(user => user.is_approved)
        setUsers(approvedUsers)
        
        if (approvedUsers.length > 0 && !isDataLoaded) {
          setSelectedUser(JSON.stringify({
            email: approvedUsers[0].email,
            town_halls_list: approvedUsers[0].town_halls_list
          }))
          setIsDataLoaded(true)
        }
        
        setTownHalls(townHallsResponse.data)
        
        // Find first available town hall for the selected user
        if (approvedUsers.length > 0 && townHallsResponse.data.length > 0) {
          const firstUser = approvedUsers[0]
          const firstAvailableTownHall = townHallsResponse.data.find(
            th => !firstUser.town_halls_list.includes(th._id)
          )
          
          if (firstAvailableTownHall) {
            setSelectedTownHall(firstAvailableTownHall.name)
          }
        }
      } catch (error) {
        console.error('Error fetching data:', error)
        toast.error('Errore durante il caricamento dei dati')
      } finally {
        setLoading(false)
      }
    }
    
    fetchData()
  }, [])

  useEffect(() => {
    if (selectedUser && townHalls.length > 0) {
      const user = JSON.parse(selectedUser)
      const firstAvailableTownHall = townHalls.find(
        th => !user.town_halls_list.includes(th._id)
      )
      
      if (firstAvailableTownHall) {
        setSelectedTownHall(firstAvailableTownHall.name)
      }
    }
  }, [selectedUser, townHalls])

  const handleUserChange = (e) => {
    const selectedUserIndex = e.target.value
    setSelectedUser(JSON.stringify({
      email: users[selectedUserIndex].email,
      town_halls_list: users[selectedUserIndex].town_halls_list
    }))
  }

  const handleTownHallChange = (e) => {
    setSelectedTownHall(e.target.value)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSubmitting(true)
    setAlert(null)
    
    try {
      const formData = {
        email: JSON.parse(selectedUser).email,
        townHall: selectedTownHall
      }
      
      const response = await userService.addTownHall(formData)
      
      // Update local state
      const updatedUser = JSON.parse(selectedUser)
      const newTownHall = townHalls.find(th => th.name === selectedTownHall)
      updatedUser.town_halls_list.push(newTownHall._id)
      setSelectedUser(JSON.stringify(updatedUser))
      
      setAlert({
        type: 'success',
        message: response.data || 'Comune aggiunto con successo'
      })
      
      toast.success('Comune aggiunto con successo')
    } catch (error) {
      console.error('Error submitting form:', error)
      setAlert({
        type: 'error',
        message: error.response?.data || 'Errore durante l\'aggiunta del comune'
      })
      
      toast.error('Errore durante l\'aggiunta del comune')
    } finally {
      setSubmitting(false)
      setTimeout(() => setAlert(null), 5000)
    }
  }

  const getUserOptions = () => {
    return users
      .filter(user => user.is_approved)
      .map((user, index) => ({
        value: index.toString(),
        label: `${user.name} ${user.surname}`
      }))
  }

  const getTownHallOptions = () => {
    if (!selectedUser) return []
    
    const user = JSON.parse(selectedUser)
    return townHalls
      .filter(th => !user.town_halls_list.includes(th._id))
      .map(th => ({
        value: th.name,
        label: th.name
      }))
  }

  const getAssignedTownHalls = () => {
    if (!selectedUser) return []
    
    const user = JSON.parse(selectedUser)
    return user.town_halls_list
      .map(thId => townHalls.find(th => th._id === thId))
      .filter(Boolean)
  }

  return (
    <div>
      <PageHeader 
        title="Aggiungi comune all'utente" 
        description="Assegna comuni agli utenti per consentire loro di visualizzare e gestire i dati"
      />
      
      {alert && (
        <Alert 
          type={alert.type} 
          message={alert.message} 
          className="mb-6"
        />
      )}
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <h2 className="text-xl font-semibold text-white">Seleziona utente e comune</h2>
            </CardHeader>
            <CardBody>
              <form onSubmit={handleSubmit}>
                <Select
                  label="Seleziona l'utente a cui aggiungere il comune"
                  value={users.findIndex(user => user.email === (selectedUser ? JSON.parse(selectedUser).email : ''))}
                  onChange={handleUserChange}
                  options={getUserOptions()}
                  disabled={loading || users.length === 0}
                />
                
                <Select
                  label="Seleziona il comune da aggiungere"
                  value={selectedTownHall}
                  onChange={handleTownHallChange}
                  options={getTownHallOptions()}
                  disabled={loading || !selectedUser || getTownHallOptions().length === 0}
                />
                
                <Button
                  type="submit"
                  isLoading={submitting}
                  disabled={loading || !selectedUser || !selectedTownHall || getTownHallOptions().length === 0}
                  className="mt-4 w-full"
                >
                  {submitting ? 'Aggiunta in corso...' : 'Aggiungi comune'}
                </Button>
              </form>
            </CardBody>
          </Card>
        </div>
        
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <h2 className="text-xl font-semibold text-white">Comuni già assegnati</h2>
            </CardHeader>
            <CardBody>
              {getAssignedTownHalls().length === 0 ? (
                <p className="text-blue-300">Nessun comune assegnato a questo utente</p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {getAssignedTownHalls().map(th => (
                    <InfoCard
                      key={th._id}
                      title={th.name}
                      descriptionName="Punti luce"
                      descriptionValue={th.light_points}
                      icon={Building}
                    />
                  ))}
                </div>
              )}
            </CardBody>
          </Card>
        </div>
      </div>
    </div>
  )
}

export default AddUserPage
