import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { userService } from '../services/api'
import PageHeader from '../components/common/PageHeader'
import Card, { CardBody } from '../components/common/Card'
import Button from '../components/common/Button'
import Select from '../components/common/Select'
import Alert from '../components/common/Alert'
import { UserCheck, UserX, Edit, Filter } from 'lucide-react'
import toast from 'react-hot-toast'

const ValidateUser = () => {
  const [users, setUsers] = useState([])
  const [userTypes, setUserTypes] = useState({})
  const [filter, setFilter] = useState('all')
  const [loading, setLoading] = useState(true)
  const [alert, setAlert] = useState(null)
  const [actionInProgress, setActionInProgress] = useState(null)
  const navigate = useNavigate()

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        setLoading(true)
        const response = await userService.getAll()
        setUsers(response.data)
      } catch (error) {
        console.error('Error fetching users:', error)
        toast.error('Errore durante il caricamento degli utenti')
      } finally {
        setLoading(false)
      }
    }
    
    fetchUsers()
  }, [])

  const handleUserTypeSelect = (email) => (e) => {
    setUserTypes({
      ...userTypes,
      [email]: e.target.value
    })
  }

  const handleFilterChange = (e) => {
    setFilter(e.target.value)
  }

  const handleValidate = async (user) => {
    setActionInProgress(user.email)
    setAlert(null)
    
    try {
      const formData = {
        email: user.email,
        user_type: userTypes[user.email] || 'DEFAULT_USER'
      }
      
      const response = await userService.validateUser(formData)
      
      // Send approval email
      try {
        await userService.sendApprovalEmail({ to: user.email, user })
      } catch (emailError) {
        console.error('Error sending approval email:', emailError)
      }
      
      // Update local state
      setUsers(users.filter(u => u.email !== user.email))
      
      toast.success('Utente validato con successo')
      setAlert({
        type: 'success',
        message: response.data || 'Utente validato con successo'
      })
    } catch (error) {
      console.error('Error validating user:', error)
      toast.error('Errore durante la validazione dell\'utente')
      setAlert({
        type: 'error',
        message: error.response?.data || 'Errore durante la validazione dell\'utente'
      })
    } finally {
      setActionInProgress(null)
    }
  }

  const handleDelete = async (user) => {
    if (!confirm(`Sei sicuro di voler eliminare l'utente ${user.name} ${user.surname}?`)) {
      return
    }
    
    setActionInProgress(user.email)
    setAlert(null)
    
    try {
      const formData = {
        email: user.email
      }
      
      const response = await userService.removeUser(formData)
      
      // Update local state
      setUsers(users.filter(u => u.email !== user.email))
      
      toast.success('Utente eliminato con successo')
      setAlert({
        type: 'success',
        message: response.data || 'Utente eliminato con successo'
      })
    } catch (error) {
      console.error('Error deleting user:', error)
      toast.error('Errore durante l\'eliminazione dell\'utente')
      setAlert({
        type: 'error',
        message: error.response?.data || 'Errore durante l\'eliminazione dell\'utente'
      })
    } finally {
      setActionInProgress(null)
    }
  }

  const handleNavigate = (user) => {
    navigate(`/valida-utente/modifica-utente/${user.email}`)
  }

  const formatDate = (isoString) => {
    const date = new Date(isoString)
    return date.toLocaleDateString('it-IT', {
      day: '2-digit',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const filteredUsers = users.filter(user => {
    if (filter === 'all') return true
    if (filter === 'notValidated') return !user.is_approved
    if (filter === 'validated') return user.is_approved
    return true
  })

  return (
    <div>
      <PageHeader 
        title="Gestione Utenti" 
        description="Valida, modifica o elimina gli account utente"
      />
      
      {alert && (
        <Alert 
          type={alert.type} 
          message={alert.message} 
          className="mb-6"
        />
      )}
      
      <div className="mb-6 flex justify-end">
        <div className="relative">
          <Select
            value={filter}
            onChange={handleFilterChange}
            options={[
              { value: 'all', label: 'Tutti gli utenti' },
              { value: 'notValidated', label: 'Utenti da validare' },
              { value: 'validated', label: 'Utenti validati' }
            ]}
            className="pl-10"
          />
          <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-blue-400" />
        </div>
      </div>
      
      <Card>
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-blue-900/30">
              <thead className="bg-slate-800">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-blue-300 uppercase tracking-wider">
                    Nome
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-blue-300 uppercase tracking-wider">
                    Cognome
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-blue-300 uppercase tracking-wider">
                    Email
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-blue-300 uppercase tracking-wider">
                    Data di iscrizione
                  </th>
                  {filter !== "validated" && (
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-blue-300 uppercase tracking-wider">
                      Tipo utente
                    </th>
                  )}
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-blue-300 uppercase tracking-wider">
                    Azioni
                  </th>
                </tr>
              </thead>
              <tbody className="bg-slate-800/50 divide-y divide-blue-900/30">
                {loading ? (
                  <tr>
                    <td colSpan={6} className="px-6 py-4 text-center text-blue-300">
                      Caricamento utenti...
                    </td>
                  </tr>
                ) : filteredUsers.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-6 py-4 text-center text-blue-300">
                      Nessun utente trovato
                    </td>
                  </tr>
                ) : (
                  filteredUsers.map((user) => (
                    <tr key={user._id} className="hover:bg-slate-700/30">
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                        {user.name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                        {user.surname}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                        {user.email}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                        {formatDate(user.date)}
                      </td>
                      {!user.is_approved && (
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                          <Select
                            value={userTypes[user.email] || 'DEFAULT_USER'}
                            onChange={handleUserTypeSelect(user.email)}
                            options={[
                              { value: 'DEFAULT_USER', label: 'Utente visualizzatore' },
                              { value: 'MAINTAINER', label: 'Manutentore' },
                              { value: 'ADMINISTRATOR', label: 'Amministratore' },
                              { value: 'SUPER_ADMIN', label: 'Super Admin' }
                            ]}
                          />
                        </td>
                      )}
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex justify-end space-x-2">
                          {!user.is_approved && (
                            <Button
                              variant="success"
                              size="sm"
                              onClick={() => handleValidate(user)}
                              isLoading={actionInProgress === user.email}
                              disabled={actionInProgress !== null}
                            >
                              <UserCheck className="h-4 w-4 mr-1" />
                              Valida
                            </Button>
                          )}
                          
                          <Button
                            variant="primary"
                            size="sm"
                            onClick={() => handleNavigate(user)}
                            disabled={actionInProgress !== null}
                          >
                            <Edit className="h-4 w-4 mr-1" />
                            Modifica
                          </Button>
                          
                          <Button
                            variant="danger"
                            size="sm"
                            onClick={() => handleDelete(user)}
                            isLoading={actionInProgress === user.email}
                            disabled={actionInProgress !== null}
                          >
                            <UserX className="h-4 w-4 mr-1" />
                            Elimina
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>
    </div>
  )
}

export default ValidateUser
